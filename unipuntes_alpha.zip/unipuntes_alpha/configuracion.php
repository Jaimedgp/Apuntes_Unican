<?php
/***********************************************************
 *
 *	ARCHIVO DE CONFIGURACIÓN GENERAL
 *
 ************************************************************/


/*NOMBRE DE LA APLICACIÓN*/
define("NOMBRE", "unipuntes");
/** Directorio donde se guardan los archivos. Previene su acceso directo desde la web.**/
define("DIRECTORIO_SECRETO", "documentos/78w3rbqx9837trbx83tf7wqeyctr7qytf7qx");

/**BASE DE DATOS**/

define("BASEDEDATOS", array(
	"TIPO" => "mysql",				// Tipo de base de datos. Opciones: mysql, sqlserver
	"SERVIDOR" => "localhost",		// Dirección del servidor
	"USUARIO" => "unipuntes",			// Usuario de la base de datos
	"CONTRASENA" => "a8472cc2c3df307da3dbe7766b5fe3e4",		// Contraseña de la base de datos
	"BASEDEDATOS" => "unipuntes"		// Nombre de la Base de Datos
));


?>